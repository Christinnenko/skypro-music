import "../Tracklist/Tracklist.css";
import * as S from "../Sidebar/Sidebar.styles.js";
import * as S from "../AudioPlayer/AudioPlayer.styles.js";
import "./EmulationLoading.css";

function EmulationTracklist() {
  return (
    <div className="centerblock__content">
      <div className="content__title playlist-title">
        <div className="playlist-title__col col01">Трек</div>
        <div className="playlist-title__col col02">ИСПОЛНИТЕЛЬ</div>
        <div className="playlist-title__col col03">АЛЬБОМ</div>
        <div className="playlist-title__col col04">
          <svg className="playlist-title__svg" alt="time">
            <use xlinkHref="/icon/sprite.svg#icon-watch"></use>
          </svg>
        </div>
      </div>
      <div className="content__playlist playlist">
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>

        <div className="playlist__item">
          <div className="playlist__track track">
            <div className="track__title">
              <div className="track__title-image">
                <img
                  src="/icon/emulate_track-image.svg"
                  alt="Обложка трека загружается"
                />
              </div>
              <div className="track__title-text">
                <a className="track__title-link" href="http://">
                  <img
                    src="/icon/emulate_track-name.svg"
                    alt="Название трека загружается"
                  />
                  <span className="track__title-span"></span>
                </a>
              </div>
            </div>
            <div className="track__author">
              <a className="track__author-link" href="http://">
                <img
                  src="/icon/emulate_track-singer.svg"
                  alt="Имя исполнителя загружается"
                />
              </a>
            </div>
            <div className="track__album">
              <a className="track__album-link" href="http://">
                <img
                  src="/icon/emulate_track-album.svg"
                  alt="Название альбома загружается"
                />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function EmulationSidebar() {
  return (
    <S.MainSidebar>
      <S.SidebarPersonal>
        <S.SidebarPersonalName>Sergey.Ivanov</S.SidebarPersonalName>
        <S.SidebarIcon>
          <svg alt="logout">
            <use xlinkHref="/icon/sprite.svg#logout"></use>
          </svg>
        </S.SidebarIcon>
      </S.SidebarPersonal>
      <S.SidebarBlock>
        <S.SidebarList>
          <S.SidebarItem>
            <S.SidebarLink href="#">
              <img src="/icon/emulate_sidebar.svg" alt="Сайдбар загружается" />
            </S.SidebarLink>
          </S.SidebarItem>
          <S.SidebarItem>
            <S.SidebarLink href="#">
              <img src="/icon/emulate_sidebar.svg" alt="Сайдбар загружается" />
            </S.SidebarLink>
          </S.SidebarItem>
          <S.SidebarItem>
            <S.SidebarLink href="#">
              <img src="/icon/emulate_sidebar.svg" alt="Сайдбар загружается" />
            </S.SidebarLink>
          </S.SidebarItem>
        </S.SidebarList>
      </S.SidebarBlock>
    </S.MainSidebar>
  );
}

function EmulationAudioPlayer() {
  return (
    <S.Bar>
      <S.BarContent>
        <S.BarPlayerProgress></S.BarPlayerProgress>
        <S.BarPlayerBlock>
          <S.BarPlayer>
            <S.PlayerControls>
              <S.PlayerBtnPrev>
                <S.PlayerBtnPrevSvg alt="prev">
                  <use xlinkHref="/icon/sprite.svg#icon-prev"></use>
                </S.PlayerBtnPrevSvg>
              </S.PlayerBtnPrev>
              <S.PlayerBtnPlay>
                <S.PlayerBtnPlaySvg alt="play">
                  <use xlinkHref="/icon/sprite.svg#icon-play"></use>
                </S.PlayerBtnPlaySvg>
              </S.PlayerBtnPlay>
              <S.PlayerBtnNext>
                <S.PlayerBtnNextSvg alt="next">
                  <use xlinkHref="/icon/sprite.svg#icon-next"></use>
                </S.PlayerBtnNextSvg>
              </S.PlayerBtnNext>
              <S.PlayerBtnRepeat>
                <S.PlayerBtnRepeatSvg alt="repeat">
                  <use xlinkHref="/icon/sprite.svg#icon-repeat"></use>
                </S.PlayerBtnRepeatSvg>
              </S.PlayerBtnRepeat>
              <S.PlayerBtnShuffle>
                <S.PlayerBtnShuffleSvg alt="shuffle">
                  <use xlinkHref="/icon/sprite.svg#icon-shuffle"></use>
                </S.PlayerBtnShuffleSvg>
              </S.PlayerBtnShuffle>
            </S.PlayerControls>

            <S.PlayerTrackPlay>
              <S.TrackPlayContain>
                <img
                  src="/icon/emulate_audioplayer.svg"
                  alt="Аудиоплеер загружается"
                />
              </S.TrackPlayContain>

              <S.TrackPlayLikeDis>
                <S.TrackPlayLike>
                  <S.TrackPlayLikeSvg alt="like">
                    <use xlinkHref="/icon/sprite.svg#icon-like"></use>
                  </S.TrackPlayLikeSvg>
                </S.TrackPlayLike>
                <S.TrackPlayDislike>
                  <S.TrackPlayDislikeSvg alt="dislike">
                    <use xlinkHref="/icon/sprite.svg#icon-dislike"></use>
                  </S.TrackPlayDislikeSvg>
                </S.TrackPlayDislike>
              </S.TrackPlayLikeDis>
            </S.PlayerTrackPlay>
          </S.BarPlayer>
          <S.VolumeBlock>
            <S.VolumeContent>
              <S.VolumeImage>
                <S.VolumeSvg alt="volume">
                  <use xlinkHref="/icon/sprite.svg#icon-volume"></use>
                </S.VolumeSvg>
              </S.VolumeImage>
              <S.VolumeProgress>
                <S.VolumeProgressLine type="range" name="range" />
              </S.VolumeProgress>
            </S.VolumeContent>
          </S.VolumeBlock>
        </S.BarPlayerBlock>
      </S.BarContent>
    </S.Bar>
  );
}

export { EmulationTracklist, EmulationSidebar, EmulationAudioPlayer };
