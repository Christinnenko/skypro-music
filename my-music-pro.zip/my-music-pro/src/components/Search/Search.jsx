import * as S from "./Search.styles.js";

function Search() {
  return (
    <S.CenterblockSearch>
      <svg className="search__svg">
        <use xlinkHref="/icon/sprite.svg#icon-search"></use>
      </svg>
      <input
        className="search__text"
        type="search"
        placeholder="Поиск"
        name="search"
      />
    </S.CenterblockSearch>
  );
}

export default Search;
